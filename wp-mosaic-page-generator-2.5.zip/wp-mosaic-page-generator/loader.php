<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
require_once (wpmpg_path . 'classes/common.php');
require_once (wpmpg_path . 'classes/postype.php');
require_once (wpmpg_path . 'classes/taxoterm.php');
require_once (wpmpg_path . 'classes/class.php');
require_once (wpmpg_path . 'classes/elementor-cpf.php');